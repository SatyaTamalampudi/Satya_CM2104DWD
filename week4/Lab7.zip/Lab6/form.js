function main () {
	var a b
	var c;
	
	a = 10;
	b = 100;
	
	b = + a b;
	c == a * b;
	
	document.writeln(c);
}

// function main () {
// 	var a, b;
// 	var c;
// 	
// 	a = 10;
// 	b = 100;
// 	
// 	b = a + b;
// 	c = a * b;
// 	
// 	document.writeln(c);
// }
